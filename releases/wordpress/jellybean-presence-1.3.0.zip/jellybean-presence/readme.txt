=== JellyBean Visitor Presence ===
Requires at least: 6.2
Requires PHP: 7.4
Stable tag: 1.3.0
License: GPL-2.0-or-later

Uses the existing Crisp widget to send signed, rate-limited arrival hints to your
JellyBean CRM. Does not add a second chat widget, analytics cookies, names, emails
or page URLs. An identifier and random request ID are sent through WordPress to
the configured JellyBean Supabase project. Session IDs are pruned after seven days
by a daily cleanup (up to one additional day). Browser sessionStorage stores a
two-minute suppression timestamp. Respect your existing Crisp consent controls:
no signal is sent until the Crisp SDK has loaded a session.

Install via Plugins > Add New > Upload Plugin. Then Settings > JellyBean Presence.
Obtain the correct Crisp Website ID and dedicated per-site signing key from CRM
operations using a secure channel. HTTPS is required. Backend enrollment must
match the site's exact origin, including www if used. Leave existing Crisp chat
active. Save settings, then click Test backend connection. This authenticated
diagnostic does not create a visitor or send any greeting. See the accompanying
office handoff guide before enabling. Upload the plugin ZIP itself, not an outer
handoff ZIP containing another ZIP.

Version 1.2.0 also disables the known legacy isolated-govee-popup-frame promotion
overlay, which can sit over Crisp's dismiss control. This narrowly scoped style
loads while the plugin is active, independently of relay/key configuration.
It does not hide Crisp or mark unread messages as read. Prefer removing the
old Govee popup snippet in WPCode permanently. Deactivate this plugin to remove
both the style protection and arrival relay.

Version 1.3.0 adds an opt-in Compact message previews setting. Enable it only on
the affected site: at most one native outside preview appears for eight seconds,
then only Crisp's native launcher/unread count remains. Messages are not marked
read, deleted or resent. Dismissal is stored in sessionStorage across same-tab
navigation; a new incoming message can show a fresh preview. No new greeting
source is added. Disable duplicate Crisp campaigns and WPCode greeting snippets;
keep the CRM's first-visit and verified-return greeting rules as the sole sender.
The preview adapter uses vendor DOM selectors verified against Crisp v4.18.3;
recheck after widget updates. Disable the setting to restore native previews.

This plugin makes outbound HTTPS POST requests to:
https://fjscqsatzsmfivpczaud.supabase.co/functions/v1/crisp-site-arrival

The browser only contacts its own WordPress server. Site keys never appear in
JavaScript or the WordPress REST settings API. This connection is intended for
this JellyBean deployment, not arbitrary third-party backends.

No guarantee of sub-five-second greetings: widget consent/load, hosting, Crisp
identity visibility, quotas and network latency still apply. Polling remains the
recovery layer. Deactivate the relay to roll back without affecting chat.
